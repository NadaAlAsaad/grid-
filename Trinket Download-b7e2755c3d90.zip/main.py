import turtle
import random

# Set up the screen
win = turtle.Screen()
win.bgcolor("white")

# Create a turtle object
grid_drawer = turtle.Turtle()
grid_drawer.speed(0)  # Fastest speed

# Function to draw a square with a random color
def draw_square(x, y):
    grid_drawer.penup()
    grid_drawer.goto(x, y)
    grid_drawer.pendown()
    r = random.randint(0,255)
    g = random.randint(0,255)
    b = random.randint(0,255)
    grid_drawer.fillcolor(r, g, b)
    grid_drawer.begin_fill()
    for _ in range(4):
        grid_drawer.forward(50)  # Side length of the square
        grid_drawer.right(90)
    grid_drawer.end_fill()

# Draw the 5x5 grid
for row in range(5):
    for col in range(5):
        x = col * 50 - 125  # Calculate x-coordinate
        y = row * 50 - 125  # Calculate y-coordinate
        draw_square(x, y)

# Keep the window open
turtle.done()